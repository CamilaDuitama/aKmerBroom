#!/usr/bin/env python3
import argparse
import os
import logging
import time
from .scripts import classify_reads, kmers


def main():
    """
    aKmerBroom: Ancient oral DNA decontamination using Bloom filters on k-mer sets
    
    This tool removes ancient oral DNA contamination from ancient DNA samples using 
    a two-step algorithm based on k-mer analysis.
    """
    parser = argparse.ArgumentParser(
        description='aKmerBroom: Ancient oral DNA decontamination using Bloom filters on k-mer sets',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  # Basic usage with Bloom filter
  aKmerBroom --ancient_bloom --input_file sample.fastq --output_prefix sample1
  
  # Using k-mers text file instead of Bloom filter
  aKmerBroom --ancient_kmers_set --input_file sample.fastq --output_prefix sample1
  
  # Custom parameters
  aKmerBroom --ancient_bloom --input_file sample.fastq --output_prefix sample1 \\
             --kmer_size 25 --anchor_proportion_cutoff 0.6

For more information, visit: https://github.com/CamilaDuitama/aKmerBroom""")
    
    # Required arguments group
    required_group = parser.add_argument_group('Required arguments')
    required_group.add_argument('--input_file', 
                               help='Path to input FASTQ/FASTA file',
                               required=True)
    required_group.add_argument('--output_prefix', 
                               help='Prefix for output files (enables batch processing)',
                               required=True)
    
    # Bloom filter method (mutually exclusive with kmers set)
    method_group = parser.add_mutually_exclusive_group(required=True)
    method_group.add_argument('--ancient_bloom', 
                             help='Use pre-built ancient k-mers Bloom filter',
                             action='store_true')
    method_group.add_argument('--ancient_kmers_set', 
                             help='Use ancient k-mers text file instead of Bloom filter',
                             action='store_true')
    
    # Optional arguments group
    optional_group = parser.add_argument_group('Optional arguments')
    optional_group.add_argument('--output',
                               help='Output directory path (default: output)',
                               required=False, default='output')
    optional_group.add_argument('--kmer_size', 
                               help='K-mer size (default: 31)', 
                               type=int, required=False)
    optional_group.add_argument('--n_consec_matches', 
                               help='Number of consecutive matches to classify read as anchor read (default: 2)',
                               type=int, required=False)
    optional_group.add_argument('--anchor_proportion_cutoff', 
                               help='Minimum proportion of anchor k-mers to classify as ancient (default: 0.5)',
                               type=float, required=False)
    optional_group.add_argument('--ancient_bloom_capacity', 
                               help='Capacity for Bloom filter if building from scratch (default: 2,000,000,000)',
                               type=int, required=False)

    args = vars(parser.parse_args())

    bloom_filt = False
    bf_capacity = 0
    ancient_kmers = False

    # Create sample-specific log filename
    if args['output_prefix']:
        log_filename = f"aKmerBroom_{args['output_prefix']}.log"
    else:
        # Use input filename if no prefix specified
        input_basename = os.path.splitext(os.path.basename(args['input_file']))[0]
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        log_filename = f"aKmerBroom_{input_basename}_{timestamp}.log"
    
    # Create and configure logger with sample-specific filename
    logging.basicConfig(filename=log_filename,
    format='%(asctime)s %(levelname)s:%(message)s', level=logging.DEBUG, filemode='w')
 
    # Creating an object
    logger = logging.getLogger()
    
    logger.info(f"Log file: {log_filename}")
    
    # Validate input file exists and is readable
    input_file = args['input_file']
    if not os.path.exists(input_file):
        logger.error(f"Input file does not exist: {input_file}")
        kmers.exit_gracefully()
    
    if not os.path.isfile(input_file):
        logger.error(f"Input path is not a file: {input_file}")
        kmers.exit_gracefully()
    
    try:
        with open(input_file, 'r') as f:
            # Try to read first line to check if file is readable
            f.readline()
    except IOError as e:
        logger.error(f"Cannot read input file {input_file}: {str(e)}")
        kmers.exit_gracefully()
    
    #check output folder does not exist else create folder
    if os.path.isdir(args["output"]):
        logger.error("Output directory already exists")
        kmers.exit_gracefully()
    else:
        output=args["output"]
        try:
            os.mkdir(output)
        except OSError as e:
            logger.error(f"Cannot create output directory {output}: {str(e)}")
            kmers.exit_gracefully()

    # set kmer_size from argument or using default here
    if not args['kmer_size']:
        k_size = 31
    else:
        try:
            k_size = int(args['kmer_size'])
            if k_size <= 0:
                logger.error(f"k-mer size must be positive, got: {k_size}")
                kmers.exit_gracefully()
            if k_size > 100:
                logger.warning(f"Very large k-mer size: {k_size}. This may cause performance issues.")
        except ValueError:
            logger.error("Error : kmer_size provided is not an integer")
            kmers.exit_gracefully()

    # set bloom filter
    if args['ancient_bloom']:
        bloom_filt = True
        bf_capacity = None
    elif args['ancient_bloom_capacity']:
        try:
            bf_capacity = int(args['ancient_bloom_capacity'])
        except ValueError:
            logger.error("Error : ancient_bloom_capacity provided is not an integer")
            kmers.exit_gracefully()
    else:
        bf_capacity = 1000 * 1000 * 1000 * 2

    # ancient kmers set
    if args['ancient_kmers_set']:
        ancient_kmers = True

    # set n_consec_matches cutoff
    if not args['n_consec_matches']:
        n_consec_matches = 2
    else:
        try:
            n_consec_matches = int(args['n_consec_matches'])
            if n_consec_matches <= 0:
                logger.error(f"Number of consecutive matches must be positive, got: {n_consec_matches}")
                kmers.exit_gracefully()
        except ValueError:
            logger.error("Error: n_consec_matches provided is not an integer")
            kmers.exit_gracefully()

    # set anchor proportion cutoff
    if not args['anchor_proportion_cutoff']:
        anchor_proportion_cutoff = 0.5
    else:
        try:
            anchor_proportion_cutoff = float(args['anchor_proportion_cutoff'])
            if not (0 <= anchor_proportion_cutoff <= 1):
                logger.error(f"Anchor proportion cutoff must be between 0 and 1, got: {anchor_proportion_cutoff}")
                kmers.exit_gracefully()
        except ValueError:
            logger.error("Error: anchor_proportion_cutoff provided is not a valid number")
            kmers.exit_gracefully()
    
    logger.info("Started...")
    # declare defaults
    logger.info("\n=== aKmerBroom: Ancient DNA Decontamination Started ===")
    logger.info(f"Input file: {args['input_file']}")
    logger.info(f"Output directory: {output}")
    logger.info(f"Output prefix: '{args['output_prefix']}'")
    logger.info(f"K-mer size: {k_size}")
    logger.info(f"Consecutive matches threshold: {n_consec_matches}")
    logger.info(f"Anchor proportion cutoff: {anchor_proportion_cutoff}")
    logger.info(f"Using {'Bloom filter' if bloom_filt else 'k-mers set'}")
    
    total_start_time = time.time()
    
    logger.info("\n--- Starting Step 1: Identifying anchor reads ---")
    anchor_kmer_set = classify_reads.classify_reads(bloom_filt,
                                                    bf_capacity,
                                                    ancient_kmers,
                                                    k_size,
                                                    n_consec_matches,
                                                    output,
                                                    args['input_file'],
                                                    args['output_prefix'])
    
    logger.info("\n--- Starting Step 2: Final classification using anchor k-mers ---")
    classify_reads.classify_reads_using_anchor_kmers(anchor_kmer_set,
                                                     k_size,
                                                     anchor_proportion_cutoff,
                                                     output,
                                                     args['output_prefix'])
    
    total_elapsed = time.time() - total_start_time
    
    # Final summary
    logger.info("\n=== aKmerBroom: WORKFLOW COMPLETED SUCCESSFULLY ===")
    logger.info(f"Total processing time: {total_elapsed//60:.0f}m {total_elapsed%60:.0f}s")
    
    # Output file information
    if args['output_prefix']:
        final_output = f"{output}/{args['output_prefix']}_annotated_reads_with_anchor_kmers.fastq"
    else:
        final_output = f"{output}/annotated_reads_with_anchor_kmers.fastq"
    
    if os.path.exists(final_output):
        file_size = os.path.getsize(final_output)
        logger.info(f"Final output: {final_output} ({file_size:,} bytes)")
    
    logger.info("Analysis complete! Check the log file for detailed statistics.")
    
    # Create and configure logger with sample-specific filename
    logging.basicConfig(filename=log_filename,
    format='%(asctime)s %(levelname)s:%(message)s', level=logging.DEBUG, filemode='w')
 
    # Creating an object
    logger = logging.getLogger()
    
    logger.info(f"Log file: {log_filename}")
    
    # Validate input file exists and is readable
    input_file = args['input_file']
    if not os.path.exists(input_file):
        logger.error(f"Input file does not exist: {input_file}")
        kmers.exit_gracefully()
    
    if not os.path.isfile(input_file):
        logger.error(f"Input path is not a file: {input_file}")
        kmers.exit_gracefully()
    
    try:
        with open(input_file, 'r') as f:
            # Try to read first line to check if file is readable
            f.readline()
    except IOError as e:
        logger.error(f"Cannot read input file {input_file}: {str(e)}")
        kmers.exit_gracefully()
    

    # set bloom filter
    if args['ancient_bloom']:
        bloom_filt = True
        bf_capacity = None
    elif args['ancient_bloom_capacity']:
        try:
            bf_capacity = int(args['ancient_bloom_capacity'])
        except ValueError:
            logger.error("Error : ancient_bloom_capacity provided is not an integer")
            kmers.exit_gracefully()
    else:
        bf_capacity = 1000 * 1000 * 1000 * 2

    # ancient kmers set
    if args['ancient_kmers_set']:
        ancient_kmers = True

    # set n_consec_matches cutoff
    if not args['n_consec_matches']:
        n_consec_matches = 2
    else:
        try:
            n_consec_matches = int(args['n_consec_matches'])
            if n_consec_matches <= 0:
                logger.error(f"Number of consecutive matches must be positive, got: {n_consec_matches}")
                kmers.exit_gracefully()
        except ValueError:
            logger.error("Error: n_consec_matches provided is not an integer")
            kmers.exit_gracefully()

    # set anchor proportion cutoff
    if not args['anchor_proportion_cutoff']:
        anchor_proportion_cutoff = 0.5
    else:
        try:
            anchor_proportion_cutoff = float(args['anchor_proportion_cutoff'])
            if not (0 <= anchor_proportion_cutoff <= 1):
                logger.error(f"Anchor proportion cutoff must be between 0 and 1, got: {anchor_proportion_cutoff}")
                kmers.exit_gracefully()
        except ValueError:
            logger.error("Error: anchor_proportion_cutoff provided is not a valid number")
            kmers.exit_gracefully()
    
    # Create sample-specific log filename
    if args['output_prefix']:
        log_filename = f"aKmerBroom_{args['output_prefix']}.log"
    else:
        # Use input filename if no prefix specified
        input_basename = os.path.splitext(os.path.basename(args['input_file']))[0]
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        log_filename = f"aKmerBroom_{input_basename}_{timestamp}.log"


if __name__ == "__main__":
    main()

